fail2ban.client.configreader module
===================================

.. automodule:: fail2ban.client.configreader
    :members:
    :undoc-members:
    :show-inheritance:
